scoreboard objectives add op_jump dummy
scoreboard objectives add jump minecraft.custom:minecraft.jump
