execute as @a[scores={jump=1..}] run function op_jump:detect
