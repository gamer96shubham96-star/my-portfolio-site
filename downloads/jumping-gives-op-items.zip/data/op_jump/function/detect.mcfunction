execute as @s run function op_jump:loot
scoreboard players set @s jump 0
