# Wishing Well event: spawn a small chest with random loot and drop diamonds/emeralds/key
say ✨ A lucky wishing well appears!
summon chest_minecart ~ ~1 ~ {CustomName:'{"text":"Wishing Well"}'}
summon item ~ ~1 ~ {Item:{id:"minecraft:diamond",Count:5b}}
summon item ~ ~1 ~ {Item:{id:"minecraft:emerald",Count:3b}}
summon item ~ ~1 ~ {Item:{id:"minecraft:tripwire_hook",Count:1b,tag:{display:{Name:'{"text":"Lucky Key","color":"gold","bold":true}'}}}}
