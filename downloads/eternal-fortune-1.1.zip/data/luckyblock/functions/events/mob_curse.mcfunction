# Mob curse: spawn mobs and give negative effects to nearest player
say 👹 You have been cursed!
execute at @p run summon zombie ~ ~1 ~ {CustomName:'{"text":"Cursed Zombie","color":"dark_red"}'}
execute at @p run summon skeleton ~ ~1 ~
effect give @p blindness 7
effect give @p nausea 7
effect give @p poison 7
