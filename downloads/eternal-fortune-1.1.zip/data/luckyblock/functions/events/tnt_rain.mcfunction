# TNT rain event: several TNT spawn above the player(s)
say 💣 TNT Rain incoming!
execute at @p run summon tnt ~ ~15 ~ {Fuse:60}
execute at @p run summon tnt ~1 ~16 ~ {Fuse:60}
execute at @p run summon tnt ~-1 ~16 ~ {Fuse:60}
execute at @p run summon tnt ~2 ~17 ~ {Fuse:60}
execute at @p run summon tnt ~-2 ~17 ~ {Fuse:60}
