# remove event items and call appropriate event function for players holding the named barrier
execute as @a[nbt={Inventory:[{id:"minecraft:barrier",tag:{display:{Name:'{"text":"__event_wishing_well"}'}}}]}] run function luckyblock:events/wishing_well
execute as @a[nbt={Inventory:[{id:"minecraft:barrier",tag:{display:{Name:'{"text":"__event_tnt_rain"}'}}}]}] run function luckyblock:events/tnt_rain
execute as @a[nbt={Inventory:[{id:"minecraft:barrier",tag:{display:{Name:'{"text":"__event_mob_curse"}'}}}]}] run function luckyblock:events/mob_curse
# cleanup any barrier event items to avoid spam
clear @a minecraft:barrier
