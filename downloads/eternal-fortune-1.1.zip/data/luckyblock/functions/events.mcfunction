# Lucky Pink Events

# Bad event - Charged TNT
execute if score @s rand matches 0 run summon tnt ~ ~1 ~ {Fuse:60,CustomName:'{"text":"Charged TNT","color":"red"}'}

# Mob event
execute if score @s rand matches 1 run summon zombie ~ ~1 ~ {CustomName:'{"text":"Lucky Doom","color":"dark_red"}'}

# Potion effects
execute if score @s rand matches 2 run effect give @p blindness 7
execute if score @s rand matches 2 run effect give @p nausea 7
execute if score @s rand matches 2 run effect give @p poison 7

# Good event - Diamond/Emeralds
execute if score @s rand matches 3 run summon item ~ ~1 ~ {Item:{id:"minecraft:diamond",Count:5}}
execute if score @s rand matches 3 run summon item ~ ~1 ~ {Item:{id:"minecraft:emerald",Count:5}}
